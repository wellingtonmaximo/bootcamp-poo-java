
public class Bootcamp {

    public void setNome(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setNome'");
    }

    public void setDescricao(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setDescricao'");
    }

    public Object getConteudos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getConteudos'");
    }

}
