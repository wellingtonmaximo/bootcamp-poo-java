
public class Dev {

    public void setNome(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setNome'");
    }

    public void inscreverBootcamp(Bootcamp bootcamp) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'inscreverBootcamp'");
    }

    public void progredir() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'progredir'");
    }

    public String calcularTotalXp() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularTotalXp'");
    }

    public String getConteudosInscritos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getConteudosInscritos'");
    }

    public String getConteudosConcluidos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getConteudosConcluidos'");
    }

}
