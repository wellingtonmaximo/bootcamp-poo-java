Desafio: Abstraindo um Bootcamp com Orientação a Objetos em Java

Descrição do Projeto

Este projeto é uma aplicação dos conceitos de **Programação Orientada a Objetos (POO)** em Java, onde abstraímos um Bootcamp com seus principais elementos: cursos, mentorias, devs e a progressão de aprendizado.

 Conceitos de POO Aplicados

 Abstração
- Modelagem de entidades do mundo real (Bootcamp, Curso, Mentoria, Dev)
- Classe abstrata `Conteudo` que serve como base para Curso e Mentoria
- Método abstrato `calcularXp()` que é implementado por cada tipo de conteúdo

Encapsulamento
- Atributos privados com modificadores de acesso adequados
- Getters e Setters para controlar o acesso aos dados
- Proteção da integridade dos objetos

 Herança
- `Curso` e `Mentoria` herdam de `Conteudo`
- Reutilização de código e criação de hierarquia de classes
- Especialização de comportamentos

Polimorfismo
- Implementação diferente do método `calcularXp()` em cada classe
- Collections usando a superclasse `Conteudo` armazenando objetos de subclasses
- Comportamento específico baseado no tipo real do objeto

Estrutura do Projeto

```
 bootcamp-poo-java
├──  Conteudo.java        (Classe abstrata base)
├──  Curso.java           (Conteúdo com carga horária)
├──  Mentoria.java        (Conteúdo com data)
├──  Bootcamp.java        (Agrupa conteúdos e devs)
├──  Dev.java             (Desenvolvedor que progride)
├──  Main.java            (Execução do programa)
└──  README.md            (Este arquivo)
```

Como Funciona

### Sistema de XP (Experiência)
- **Curso**: XP = Carga Horária × 10
- **Mentoria**: XP = 30 (fixo: 10 padrão + 20 bônus)

### Fluxo de Uso
1. Criar cursos e mentorias
2. Criar um Bootcamp e adicionar conteúdos
3. Criar Devs e inscrevê-los no Bootcamp
4. Devs progridem nos conteúdos
5. Calcular o XP total acumulado

Como Executar

### Pré-requisitos
- Java JDK 11 ou superior instalado
- IDE Java (IntelliJ IDEA, Eclipse, VS Code) ou terminal

### Passos para Executar

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/bootcamp-poo-java.git
cd bootcamp-poo-java
```

2. Compile os arquivos:
```bash
javac *.java
```

3. Execute o programa:
```bash
java Main
```

Exemplo de Saída

```
Conteúdos Inscritos João: [Curso{...}, Curso{...}, Mentoria{...}]
-
Conteúdos Inscritos João: [Mentoria{...}]
Conteúdos Concluídos João: [Curso{...}, Curso{...}]
XP: 120.0

-------

Conteúdos Inscritos Maria: [Curso{...}, Curso{...}, Mentoria{...}]
-
Conteúdos Inscritos Maria: []
Conteúdos Concluídos Maria: [Curso{...}, Curso{...}, Mentoria{...}]
XP: 150.0
```

Possíveis Evoluções

- [ ] Sistema de níveis (Bronze, Prata, Ouro, Platina)
- [ ] Geração de certificados ao concluir o bootcamp
- [ ] Ranking de devs por XP
- [ ] Sistema de pré-requisitos entre cursos
- [ ] Avaliações e feedback dos conteúdos
- [ ] Persistência em banco de dados
- [ ] Interface gráfica (JavaFX)
- [ ] API REST com Spring Boot
- [ ] Sistema de badges e conquistas
- [ ] Notificações de novas mentorias

Tecnologias Utilizadas

- Java 11+
- Orientação a Objetos
- Collections Framework (Set, LinkedHashSet, HashSet)
- Optional
- LocalDate (Java Time API)
- Streams

Autor

Desenvolvido como parte do desafio de POO da DIO (Digital Innovation One)

Licença

Este projeto está sob a licença MIT.



